simple-quiz
===========

A simple quiz site built using Flask.

Running: python quiz_site.py will run on localhost:5000.

See quiz_template and the example quizzes/reddiquette to see how to write a quiz.

After updating quizzes, you need to restart the site.
